<?php
$post = $wp_query->post;
if ( in_category( array( 'mansion', 'bathroom', 'hood', 'heater', 'toilet', 'other' ) ) ) {
  
get_header();
$cat_info = get_category_by_slug($category_name);
$cat_name = $cat_info -> name;
$cat_slug = $cat_info -> slug;
?>

<?php if(have_posts()): while(have_posts()): the_post(); ?>
  <div class="container">
    <div id="container--left">
      <?php get_sidebar(); ?>
    </div>

    <div id="container--right">
      <main>
        <h1 id="title--page">�{�H����</h1>
        <div id="work--single" class="background--page">
          <article>
            <p id="word--work--cat"><img src="<?php echo home_url(); ?>/img/work/icon--work--cat.png" alt="�H�����5�N�ۏ�">���S�Ă������z�ł�!</p>
            <hr>
            <div id="date--single"><?php the_date( 'Y.m.d' ); ?></div>
            <h2 id="title--single"><?php the_title(); ?></h2>
            <p class="subtitle--work--single">���܂Ŏg�p���Ă������i<br><?php echo get_post_meta($post->ID, 'Old', true); ?></p>
            <p class="subtitle--work--single">����g�p�������i<br><?php echo get_post_meta($post->ID, 'Tool', true); ?></p>

            <p class="subtitle--work--single">�{�H�O�ʐ^</p>
            <ul class="work-pic--single">
              <?php
              $cf  = get_post_custom( $post->ID );
              $gallery = $cf['BeforePic'];
              if (!empty($gallery[0])) {
                foreach ($gallery as $image) {
                  if (!empty($image)) {
                    $file = wp_get_attachment_url($image);
                    $file1 = wp_get_attachment_image_src($image, medium);
                    if (empty($file)) {
                      break;
                    } ?>
                    <li><img src="<?php echo $file1[0]; ?>"></li>
                  <?php }
                }
              } ?>
            </ul>

            <p class="subtitle--work--single">�{�H��ʐ^</p>
            <ul class="work-pic--single">
              <?php
              $cf  = get_post_custom( $post->ID );
              $gallery = $cf['AfterPic'];
              if (!empty($gallery[0])) {
                foreach ($gallery as $image) {
                  if (!empty($image)) {
                    $file = wp_get_attachment_url($image);
                    $file1 = wp_get_attachment_image_src($image, medium);
                    if (empty($file)) {
                      break;
                    } ?>
                    <li><img src="<?php echo $file1[0]; ?>"></li>
                  <?php } 
                }
              } ?>
            </ul>

�@          <p class="frame--cat__price">���H���� <?php echo number_format(get_post_meta($post->ID,'Price',true));?></p>
            <p class="subtitle--work--single">�H������ <?php echo get_post_meta($post->ID, 'Time', true); ?></p>
            <p class="subtitle--work--single">�H���S�� <?php echo get_post_meta($post->ID, 'Person', true); ?></p>
          </article>

          <nav>
            <ul class="page-navi">
              <li><?php next_post_link('%link', '���̋L����', TRUE); ?></li>
              <li><a href="<?php echo home_url(); ?>/<?php echo $cat_slug; ?>">�ꗗ�֖߂�</a></li>
              <li><?php previous_post_link('%link', '�O�̋L����', TRUE); ?></li>
            </ul>
          </nav>

          <nav>
            <h3 id="subtitle--page--cat">�J�e�S���[</h2>
            <ul id="work-list--cat">
              <li><a class="opacity" href="<?php echo home_url(); ?>/work/mansion/">�d�C������</a></li>
              <li><a class="opacity" href="<?php echo home_url(); ?>/work/bathroom/">�o�X�����g�[�@</a></li>
              <li><a class="opacity" href="<?php echo home_url(); ?>/work/hood/">�����W�t�[�h</a></li>
              <li><a class="opacity" href="<?php echo home_url(); ?>/work/heater/">������</a></li>
              <li><a class="opacity" href="<?php echo home_url(); ?>/work/toilet/">�g�C��</a></li>
              <li><a class="opacity" href="<?php echo home_url(); ?>/work/other/">���̑�</a></li>
            </ul>
          </nav>
        </div>
      </main>
     </div>
  </div>
<?php endwhile; ?>

<?php endif; wp_reset_query(); ?>

<?php get_footer(); ?>  
  
<?php  
} else {
  
  if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

get_header(); ?>

<?php if ( astra_page_layout() == 'left-sidebar' ) : ?>

	<?php get_sidebar(); ?>

<?php endif ?>

	<div id="primary" <?php astra_primary_class(); ?>>

		<?php astra_primary_content_top(); ?>

		<?php astra_content_loop(); ?>

		<?php astra_primary_content_bottom(); ?>

	</div><!-- #primary -->

<?php if ( astra_page_layout() == 'right-sidebar' ) : ?>

	<?php get_sidebar(); ?>

<?php endif ?>

<?php get_footer();
  
}
?>
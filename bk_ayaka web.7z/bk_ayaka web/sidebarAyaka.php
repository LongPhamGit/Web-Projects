<aside>
  <?php if( is_home() ) { ?>
    <a class="bnr opacity" href="<?php echo home_url(); ?>/concept/"><img src="<?php echo get_template_directory_uri(); ?>/images/concept--side.png" alt="アヤカサービスが選ばれる理由"></a>
  <?php } ?>
    <?php
    $args = array ( 'category__in' => array( 3, 4, 5, 6, 7, 8 ) );
    $query = new WP_Query($args);
    $get_num = $query->found_posts;
    ?>
    <div id="counter--work--side" class="menu--side--top">
 ? ? ?<h2 class="title--side">施工事例</h2>
      <div class="bg-white--side">
        <p id="counter--work--side__word">皆様に選ばれて埼玉NO<span class="number">1</span>!!</p>
        <p id="counter--work--side__number">現在<span><?php echo $get_num; ?>件</span>掲載中</p>
        <a class="btn" href="<?php echo home_url(); ?>/mansion/"><span class="btn--before">?</span>施工実績はこちら</a>
      </div>
    </div>
    <?php wp_reset_query(); ?>
    <a class="bnr opacity" href="<?php echo home_url(); ?>/concept/"><img src="<?php echo get_template_directory_uri(); ?>/images/concept--side.png" alt="アヤカサービスが選ばれる理由"></a>
    <a class="bnr opacity" href="<?php echo home_url(); ?>/contact/"><img src="<?php echo get_template_directory_uri(); ?>/images/contact--side.png" alt="お見積りの依頼はお気軽に！！"></a>
  <?php if( is_category() || is_single() ) { 
    $args = array ( 'category__in' => array( 3, 4, 5, 6, 7, 8 ) );
    $query = new WP_Query($args);
    $get_num = $query->found_posts;
    if ( !is_category( array ( 1,2,10,11 ) ) ) {
    ?>
      <div id="menu--side--cat">
        <h2 class="title--side">カテゴリー</h2>
        <div id="bg-white--side--cat">
          <ul id="menu--side--cat__ul">
            <?php wp_list_categories('title_li=&depth=1&hide_empty=0&orderby=id&include=3,4,5,6,7,8'); ?>
          </ul>
        </div>
      </div>
    <?php }; ?>
    <div id="counter--work--side" class="menu--side--top">
 ? ? ?<h2 class="title--side">施工事例</h2>
      <div class="bg-white--side">
        <p id="counter--work--side__word">皆様に選ばれて埼玉NO<span class="number">1</span>!!</p>
        <p id="counter--work--side__number">現在<span><?php echo $get_num; ?>件</span>掲載中</p>
 ? ? ? ?<a class="btn" href="<?php echo home_url(); ?>/work"><span class="btn--before"></span>施工事例もご覧ください</a>
      </div>
    </div>
    <a class="bnr opacity" href="<?php echo home_url(); ?>/concept/"><img src="<?php echo get_template_directory_uri(); ?>/images/concept--side.png" alt="アヤカサービスが選ばれる理由"></a>
    <a class="bnr opacity" href="<?php echo home_url(); ?>/contact/"><img src="<?php echo get_template_directory_uri(); ?>/images/contact--side.png" alt="お見積りの依頼はお気軽に！！"></a>
  <?php }; ?>


  <div class="menu--side">
    <h2 class="title--side">お客様の声</h2>
    <div class="bg-white--side">
      <?php
      $chosen_id = 2; // カテゴリID
      $thisCat = get_category($chosen_id);
      ?>
      <div id="voice--side__count">現在 <span><?php echo $thisCat->count; ?></span>件</div>
      <p class="title--side__sub">理想の環境になったお客様から<br><span id="sub__voice--side">喜びの声続々！</span></p>
      <img src="<?php echo get_template_directory_uri(); ?>/images/voice--side.jpg" alt="">
      <a class="btn" href="<?php echo home_url(); ?>/voice/"><span class="btn--before">?</span>お客様の声はこちら</a>
    </div>
  </div>

  <div class="menu--side">
    <h2 class="title--side">会社概要</h2>
    <div class="bg-white--side">
      <img src="<?php echo get_template_directory_uri(); ?>/images/company--side.jpg" alt="">
      <p id="sub__company--side">(有)アヤカサービス</p>
      <address id="company--side__add">
        住所：埼玉県さいたま市見沼区東門前<span class="number">47-1-104</span><br>
        営業時間：平日<span class="number">9</span>時～<span class="number">17</span>時迄<br>
        <img class="icon--freedial" src="<?php echo get_template_directory_uri(); ?>/images/freedial--side.png" alt=""><span id="tel--side" class="fw-b">0120-39-8470</span>
      </address>
      <a class="btn" href="<?php echo home_url(); ?>/company/"><span class="btn--before">?</span>会社概要はこちら</a>
    </div>
  </div>
  <div class="menu--side">
 ? ?<h2 class="title--side">最新情報</h2>
    <div class="bg-white--side">
 ? ? ?<p class="title--side__sub">ご参考にしてください<br><span id="sub__blog--side">工事事例ご紹介</span></p>
 ? ? ?<a class="btn" href="<?php echo home_url(); ?>/blog/"><span class="btn--before"></span>最新情報はこちら</a>
    </div>
  </div>
</aside>